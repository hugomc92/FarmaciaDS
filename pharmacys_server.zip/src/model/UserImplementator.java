package model;

public interface UserImplementator {
	public abstract boolean sendResetMail();
	public abstract boolean sendVerificationMail();
}
