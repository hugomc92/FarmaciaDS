package util;

public class ServerConfig {
	/* Local 
	public static final String dataDirectory = "/Users/roman/Documents/workspace/pharmacys/WebContent/data";
	public static final String server = "localhost";*/
	
	/* Remote */
	public static final String dataDirectory = "/var/lib/tomcat7/webapps/pharmacys/data";
	public static final String server = "40.68.126.158";
}
