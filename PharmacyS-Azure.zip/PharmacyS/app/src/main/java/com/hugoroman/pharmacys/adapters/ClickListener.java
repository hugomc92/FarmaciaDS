package com.hugoroman.pharmacys.adapters;

import android.view.View;

public interface ClickListener {

    void onItemClick(int position, View v);
}